#!/bin/bash

if [ -f 'tengine-2.2.0.tar.gz' -a -f 'zlib-1.2.11.tar.gz' -a -f  'pcre-8.39.tar.gz' -a -f 'openssl-1.0.2.tar.gz' ]; then
    mkdir /usr/local/tengine
    tar xf zlib-1.2.11.tar.gz   -C /usr/local/
    tar xf pcre-8.39.tar.gz     -C /usr/local/
    tar xf openssl-1.0.2.tar.gz -C /usr/local/
    tar xf tengine-2.2.0.tar.gz 
fi

cd tengine-2.2.0 && ./configure --prefix=/usr/local/tengine --with-zlib=/usr/local/zlib-1.2.11 --with-pcre=/usr/local/pcre-8.39 --with-openssl=/usr/local/openssl-1.0.2
make && make install
cp ../tengine /etc/init.d/ && chmod +x /etc/init.d/tengine
#chkconfig tengine on
#service tengine start
