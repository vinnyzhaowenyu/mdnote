#!/bin/bash
# Author: admin@zhaowenyu.com

# prepare env
## yum install  gcc make gcc-c++ perl -y
mkdir /usr/local/tengine

# prepare software
if [ -f 'tengine' -a -f 'tengine-2.2.0.tar.gz' -a -f 'zlib-1.2.11.tar.gz' -a -f  'pcre-8.39.tar.gz' -a -f 'openssl-1.0.2.tar.gz' ]; then
    tar xf zlib-1.2.11.tar.gz   -C /tmp
    tar xf pcre-8.39.tar.gz     -C /tmp
    tar xf openssl-1.0.2.tar.gz -C /tmp
    tar xf tengine-2.2.0.tar.gz -C /tmp 
    cp tengine /tmp/tengine
fi

# Compile install
cd /tmp/tengine-2.2.0 && ./configure --prefix=/usr/local/tengine --with-zlib=/tmp/zlib-1.2.11 --with-pcre=/tmp/pcre-8.39 --with-openssl=/tmp/openssl-1.0.2
make && make install
cp /tmp/tengine /etc/init.d/ && chmod +x /etc/init.d/tengine

# clean env
rm -fr  /tmp/zlib-1.2.11  /tmp/pcre-8.39  /tmp/openssl-1.0.2 /tmp/tengine-2.2.0 /tmp/tengine

# start tengine
## chkconfig tengine on
## service tengine start
echo "start now : service tengine start"
echo "start tengine on boot : checkconfig tengine on"

